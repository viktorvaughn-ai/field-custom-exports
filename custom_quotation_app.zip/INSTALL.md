# Custom Quotation App — Installation Guide

## What this app does
Overrides ERPNext's server-side Quotation calculation so that:
- **Square Meter** items: `amount = (width_mm/1000) × length_mtr × pcs_ctn × total_ctn × rate`
- **PCS** items: `amount = pcs_ctn × total_ctn × rate`
- GST 18%, Transport Charges, and Other Charges are applied on top
- All totals saved correctly to the database (fixes print, Sales Order conversion, etc.)

---

## Prerequisites
- ERPNext v15 installed via `bench`
- You are on the server where bench is installed
- Your site name (e.g. `mysite.localhost`)

---

## Step 1 — Copy app to bench apps folder

```bash
# Go to your bench directory
cd /home/frappe/frappe-bench   # or wherever your bench is

# Copy the app folder into bench/apps/
cp -r /path/to/custom_quotation apps/
```

---

## Step 2 — Install the app

```bash
# Install Python package in bench environment
bench pip install -e apps/custom_quotation

# Install app on your site
bench --site YOUR_SITE_NAME install-app custom_quotation
```

Replace `YOUR_SITE_NAME` with your actual site name e.g. `mysite.localhost`

---

## Step 3 — Run migrations and restart

```bash
bench --site YOUR_SITE_NAME migrate
bench restart
```

---

## Step 4 — Verify it works

1. Open any Quotation in ERPNext
2. Add items with Square Meter or PCS UOM
3. Fill in Width (MM), Length (MTR), PCS/CTN, Total CTN, Rate
4. **Save** the Quotation
5. Re-open it — the amounts in the database should now be correct
6. Print it — printed values will match your custom formula

---

## Custom Fields Required

Make sure these custom fields exist (via Customize Form):

### On Quotation Item:
| Field Name | Type |
|---|---|
| custom_width_mm | Float |
| custom_length_mtr | Float |
| custom_pcsctn | Float |
| custom_total_ctn | Float |

### On Quotation:
| Field Name | Type |
|---|---|
| custom_transport_charges | Currency |
| custom_other_charges | Currency |

---

## Uninstall (if needed)

```bash
bench --site YOUR_SITE_NAME uninstall-app custom_quotation
bench restart
```
