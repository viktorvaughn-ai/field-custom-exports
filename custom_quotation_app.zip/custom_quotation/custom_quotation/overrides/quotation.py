"""
custom_quotation/overrides/quotation.py

Server-side calculation override for ERPNext v15 Quotation.

Supported UOMs:
  - "Square Meter" : value = (width_mm / 1000) * length_mtr * pcs_ctn * total_ctn * rate
  - "PCS"          : value = pcs_ctn * total_ctn * rate
  - anything else  : leave ERPNext's own qty * rate untouched

Custom fields expected on Quotation Item:
  custom_width_mm   (Float)
  custom_length_mtr (Float)
  custom_pcsctn     (Int / Float)
  custom_total_ctn  (Float)

Custom fields expected on Quotation:
  custom_transport_charges (Currency)
  custom_other_charges     (Currency)
"""

import frappe
from frappe.utils import flt, rounded
from erpnext.selling.doctype.quotation.quotation import Quotation

SQUARE_METER_UOMS = {"square meter", "sqmtr", "sqm"}
PCS_UOMS          = {"pcs", "pc", "piece", "pieces"}
GST_RATE          = 0.18


def _calculate_item_amount(item):
    """
    Return the custom-calculated amount for one Quotation Item row.
    Returns None if the UOM is not handled (caller keeps ERPNext value).
    """
    uom         = (item.uom or "").strip().lower()
    pcs_ctn     = flt(item.custom_pcsctn)
    total_ctn   = flt(item.custom_total_ctn)
    rate        = flt(item.rate)

    if uom in SQUARE_METER_UOMS:
        width_m = flt(item.custom_width_mm) / 1000.0
        length  = flt(item.custom_length_mtr)
        if width_m > 0 and length > 0 and pcs_ctn > 0 and total_ctn > 0 and rate > 0:
            return flt(width_m * length * pcs_ctn * total_ctn * rate, 2)

    elif uom in PCS_UOMS:
        if pcs_ctn > 0 and total_ctn > 0 and rate > 0:
            return flt(pcs_ctn * total_ctn * rate, 2)

    return None  # Not handled — leave to ERPNext


def recalculate_quotation(doc, method=None):
    """
    Main calculation entry point.
    Called on validate + before_save via hooks.py doc_events.
    Also called by CustomQuotation.calculate_taxes_and_totals().
    """
    sub_total = 0.0

    # ── Step 1: Recalculate each item's amount ─────────────────
    for item in doc.items:
        custom_amount = _calculate_item_amount(item)
        if custom_amount is not None:
            item.amount      = custom_amount
            item.base_amount = custom_amount   # assume single currency for now
        sub_total += flt(item.amount)

    # ── Step 2: GST 18% ────────────────────────────────────────
    gst_amount = flt(sub_total * GST_RATE, 2)

    # ── Step 3: Custom charges ─────────────────────────────────
    transport  = flt(doc.custom_transport_charges)
    other      = flt(doc.custom_other_charges)
    net_amount = flt(sub_total + gst_amount + transport + other, 2)

    # ── Step 4: Override ERPNext totals on the doc ─────────────
    doc.total                   = flt(sub_total, 2)
    doc.net_total               = flt(sub_total, 2)
    doc.base_total              = flt(sub_total, 2)
    doc.base_net_total          = flt(sub_total, 2)
    doc.total_taxes_and_charges = flt(gst_amount + transport + other, 2)
    doc.grand_total             = net_amount
    doc.base_grand_total        = net_amount
    doc.rounded_total           = net_amount
    doc.rounding_adjustment     = 0.0

    # ── Step 5: Patch the GST row in taxes table ───────────────
    for tax in (doc.taxes or []):
        if flt(tax.rate) == 18:
            tax.tax_amount                           = gst_amount
            tax.base_tax_amount                      = gst_amount
            tax.total                                = flt(sub_total + gst_amount, 2)
            tax.base_total                           = flt(sub_total + gst_amount, 2)
            tax.tax_amount_after_discount_amount     = gst_amount

    frappe.logger().debug(
        f"[CustomQuotation] sub={sub_total} gst={gst_amount} "
        f"transport={transport} other={other} net={net_amount}"
    )


class CustomQuotation(Quotation):
    """
    Subclass of ERPNext Quotation.
    Overrides calculate_taxes_and_totals so our formula wins
    every time ERPNext tries to recalculate (save, submit, amend, etc.)
    """

    def calculate_taxes_and_totals(self):
        # Run ERPNext's native calculation first
        # (sets qty, uom conversions, discount, etc.)
        super().calculate_taxes_and_totals()
        # Then immediately override with our custom logic
        recalculate_quotation(self)

    def validate(self):
        super().validate()
        recalculate_quotation(self)

    def before_save(self):
        recalculate_quotation(self)
