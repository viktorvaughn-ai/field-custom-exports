from setuptools import setup, find_packages

setup(
    name="custom_quotation",
    version="1.0.0",
    description="Custom Quotation calculation for ERPNext v15",
    author="Your Company",
    author_email="admin@yourcompany.com",
    packages=find_packages(),
    zip_safe=False,
    include_package_data=True,
)
