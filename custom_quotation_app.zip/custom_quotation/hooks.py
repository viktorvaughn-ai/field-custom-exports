app_name = "custom_quotation"
app_title = "Custom Quotation"
app_publisher = "Your Company"
app_description = "Server-side custom calculation for Quotation (Square Meter & PCS UOM)"
app_version = "1.0.0"
app_email = "admin@yourcompany.com"
app_license = "MIT"

# Override Quotation document class so our calculate() runs on every save
override_doctype_class = {
    "Quotation": "custom_quotation.custom_quotation.overrides.quotation.CustomQuotation"
}

# Also hook into validate so it runs before save
doc_events = {
    "Quotation": {
        "validate": "custom_quotation.custom_quotation.overrides.quotation.recalculate_quotation",
        "before_save": "custom_quotation.custom_quotation.overrides.quotation.recalculate_quotation",
    }
}
